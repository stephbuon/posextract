def main():
    print('This works.')  
                        
if __name__ == "__main__":
    main()
