


You can acccess our Wiki to see addtional info
links to our evaluation data sets. 
https://github.com/stephbuon/posextract/wiki


**posextractr**


Example Usage:
`python -m posextractor.posextract --data_column sentence --id_column sentence_id test.csv output.csv`

Example Usage without input file:
`python -m posextractor.posextract "This is a sentence." output.csv`


For list of spaCy symbols: https://github.com/explosion/spaCy/blob/master/spacy/symbols.pyx
